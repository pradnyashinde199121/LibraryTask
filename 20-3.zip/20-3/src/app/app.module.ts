
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import {  MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatNativeDateModule} from '@angular/material/core';
import { FormsModule } from '@angular/forms';

//import { MaterialModule,  MatNativeDateModule } from '@angular/material';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashbordComponent } from './dashbord/dashbord.component';
import { SignupComponent } from './signup/signup.component';
import { AgentsignupComponent } from './agentsignup/agentsignup.component';
import { ActorDetailComponent } from './actor-detail/actor-detail.component';
import { AgentDetailComponent } from './agent-detail/agent-detail.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SignupService } from './services/signup.service';
import { ActorService } from './services/actor/actor.service';
import { AgentService } from './services/agent/agent.service';
import { BrandService } from './services/brand/brand.service';
import { TokenInterceptorService } from './services/JWtoken/token-interceptor.service';
import { CheckPasswordDirective } from './check-password.directive'

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashbordComponent,
    SignupComponent,
    AgentsignupComponent,
    ActorDetailComponent,
    AgentDetailComponent,
    CheckPasswordDirective
  ],
  imports: [
    BrowserModule,FormsModule, HttpClientModule,AppRoutingModule,
    MatDatepickerModule,MatFormFieldModule,MatInputModule,MatNativeDateModule,
    BrowserAnimationsModule
  ],
  providers: [SignupService,ActorService,AgentService,BrandService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass:TokenInterceptorService,
      multi:true
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SignupService} from '../services/signup.service';

@Component({
  selector: 'app-agentsignup',
  templateUrl: './agentsignup.component.html',
  styleUrls: ['./agentsignup.component.css']
})
export class AgentsignupComponent implements OnInit {
  fname:any;
  lname:any;
  phno:any;
  pswd:any;
  cpswd:any;
  signupObj:any;
  emails:any;
  constructor(private route:Router,private SignupService:SignupService) { }

  ngOnInit(): void {

  }
  signUp(){
    this.signupObj={  "Email":this.emails,"FirstName":this.fname, "LastName":this.lname,"Role":1, "MobileNo":this.phno, "Password":this.pswd, "Status":0}
    console.log(this.signupObj);
    this.SignupService.setSignUp(this.signupObj).subscribe(x=>{
      console.log("data");
      console.log(x);
    });
    this.route.navigate(['/agent-detail'])
      }
      keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
      
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
          event.preventDefault();
        }
      }

}

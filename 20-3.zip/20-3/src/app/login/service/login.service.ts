import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }
  getJswToken(){
    return localStorage.getItem('jwttoken');
  }

  setlogin(data):Observable<any> {           //  Post Api for login 
    return this.http.post<any>('http://209.151.154.112:3010/user/login', data);
  }
}

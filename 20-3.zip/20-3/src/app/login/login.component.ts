import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  Email:any;
  Password:any;
  constructor(private route:Router, private LoginService: LoginService) { }

  ngOnInit(): void {
  }
  signIn(){
    const data = {
      Email: this.Email,
      Password: this.Password
    }
    console.log(data);
    this.LoginService.setlogin(data).subscribe(x=>{
console.log(x);
this.route.navigate(['/dashbord']);
    });

  }
}

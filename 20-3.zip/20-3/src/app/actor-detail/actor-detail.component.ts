import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { ActorService } from '../services/actor/actor.service'
@Component({
  selector: 'app-actor-detail',
  templateUrl: './actor-detail.component.html',
  styleUrls: ['./actor-detail.component.css']
})
export class ActorDetailComponent implements OnInit {
  files  = []; 
  @ViewChild("fileUpload", {static: false}) fileUpload: ElementRef;

  constructor(private route:Router, private sanitizer: DomSanitizer,private ActorService:ActorService) { }

  ngOnInit(): void {
  }
  signUp(){
    this.route.navigate(['/dashbord'])
  }

  
  uploadFile(file) {  //step3
    const data = {
      files:file.data
    }
  
  }
  private uploadFiles() {  //step2
    this.fileUpload.nativeElement.value = '';  
    this.files.forEach(file => {  
      this.uploadFile(file);  
    }); 
  }
  sendUploadFiles() {  // step1
    this.files  = []; //empty the array for new request
    const fileUpload = this.fileUpload.nativeElement;
    fileUpload.onchange = () => {  
    for (let index = 0; index < fileUpload.files.length; index++)  
  {  
   const file = fileUpload.files[index];  
   this.files.push({ data: file}); 
   //--------------------------download Files-------------------------------//
   const data=file;
   const blob = new Blob([data], { type: 'application/octet-stream' });
   //this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
  }   

    this.uploadFiles();  
  };  
  fileUpload.click();  
  
  }

}

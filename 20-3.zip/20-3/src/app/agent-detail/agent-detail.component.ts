import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-agent-detail',
  templateUrl: './agent-detail.component.html',
  styleUrls: ['./agent-detail.component.css']
})
export class AgentDetailComponent implements OnInit {

  form: FormGroup;
  typeBrand:any=[{type:"ADIDAS"},{type:"NIKE"}];
  brandType:any;
  filedata:any;
  isSelected:boolean=true;
  selectedValue :any ='Brand & Designation';
  constructor(private route:Router,private http: HttpClient) { }

  ngOnInit(): void {
  }
  signUp(){
    this.route.navigate(['/dashbord'])
  }
  fileEvent(e){
    this.filedata = e.target.files[0];
}
/* Upload button functioanlity */
onSubmitform(f: NgForm) {
   
  var myFormData = new FormData();
  const headers = new HttpHeaders();
  headers.append('Content-Type', 'multipart/form-data');
  headers.append('Accept', 'application/json');
  myFormData.append('image', this.filedata);
  /* Image Post Request */
  this.http.post('http://localhost/save.php', myFormData, {
  headers: headers
  }).subscribe(data => {
   //Check success message
   console.log(data);
  });  
  this.signUp();

}
/* file upload */
}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ActorService {

  constructor(private http: HttpClient) { }

  UpdateActorInfo(actordata):Observable<any> {           //Post Api for update info of artist
    return this.http.post<any>('https://', actordata);     
  }
  updateActor(updateData){
    return this.http.put<any>('https://', updateData);    //Put Api for update
  }

        
  verifyActor(verifyData){
    return this.http.put<any>('https://', verifyData);      //Put api for verify actor --admin api
  }

  getUploads(uploadData):Observable<any> {
    let formData = new FormData();
    return this.http.post<any>('https://',formData); 
  }
 
}

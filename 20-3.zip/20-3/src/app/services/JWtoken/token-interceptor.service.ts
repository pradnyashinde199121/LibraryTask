import { Injectable,Injector } from '@angular/core';
import { HttpInterceptor} from '@angular/common/http';
import { LoginService} from '../../login/service/login.service'
@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService {

  constructor(private injector: Injector) { }

 intercept(req, next){
    let service = this.injector.get(LoginService);
    let tokenizedReq = req.clone({
      setHeaders: {
        Authorization:`Bearer ${service.getJswToken()}`
      }
    })
    return next.handle(tokenizedReq);
  }
}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor( private http: HttpClient) { }

  setSignUp(data):Observable<any> {           //  Post Api for SignUp 
    return this.http.post<any>('http://209.151.154.112:3010/user/signup', data);
  }
  updateFirstData(updateData){                  //Put Api for update
    return this.http.put<any>('https://', updateData);
  }
  getAllActors():Observable<any>{             //Get for fetch all actors
    return this.http.get<any>('https://');
  }
  getAllAgents():Observable<any>{             //Get for fetch all agents
    return this.http.get<any>('https://');
  }
  getSpecificActor(email):Observable<any> {       //Get for fetch specific actor
    return this.http.get<any>('https:// /?q='+ email);
  }
  getSpecificAgent(email):Observable<any> {         //Get for fetch specific agent
    return this.http.get<any>('https:// /?q='+ email);
  }
  
}

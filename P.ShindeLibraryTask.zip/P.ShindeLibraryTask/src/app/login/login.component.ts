import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService} from '../common.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  Email:any;
  pswd:any;
  obj:any;
  check:any
  loginData:any;
  constructor(private route:Router, private CommonService:CommonService) { }

  ngOnInit() {
    this.obj={"email":this.Email,"password":this.pswd};
    this.CommonService.getLogin().subscribe(x=>{
      this.loginData =x;
      //  this.check =x.email==this.Email &&   x.password == this.pswd
      // if( !this.check){
      //   alert("email does not exist")

      // }
      console.log("data");
      console.log(this.loginData);
    });
  }
  signIn(){
    this.check= this.loginData.find(x=>
      x.email===this.Email && x.password === this.pswd
  
    )
    if(this.check){
      this.route.navigate(['/dashbord']);
    }
    
    else{
      alert("email not registor");
    }
  }

}
